import sys
from controller import Controller
from bot import fight

def main():
    if len(sys.argv) != 2 or sys.argv[1] not in ['1', '2']:
        print("Usage: python run_bot.py [1|2]")
        print("1 for player 1, 2 for player 2")
        sys.exit(1)
    
    player_num = sys.argv[1]
    controller = Controller(player_num)
    
    print("Connecting to game...")
    controller.connect()
    print("Connected successfully!")
    
    try:
        while True:
            # Get current game state
            game_state = controller.get_game_state()
            
            # Get command from bot
            command = fight(game_state, player_num)
            
            # Send command to game
            controller.send_command(command)
            
            # Check if round is over
            if game_state.is_round_over:
                print("Round over!")
                break
    
    except KeyboardInterrupt:
        print("\nBot interrupted")
    
    except Exception as e:
        print(f"Error: {e}")
    
    finally:
        controller.close()

if __name__ == "__main__":
    main()
