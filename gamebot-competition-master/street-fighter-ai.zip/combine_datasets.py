import os
import pandas as pd
import glob
import argparse

def combine_datasets(directory='dataset', output_file='combined_dataset.csv'):
    # Get all CSV files in the directory
    csv_files = glob.glob(os.path.join(directory, '*.csv'))
    
    if not csv_files:
        print(f"No CSV files found in {directory}")
        return
    
    print(f"Found {len(csv_files)} CSV files")
    
    # Read and combine all CSV files
    dfs = []
    for file in csv_files:
        print(f"Reading {file}")
        df = pd.read_csv(file)
        dfs.append(df)
    
    # Combine all dataframes
    combined_df = pd.concat(dfs, ignore_index=True)
    
    # Save combined dataset
    combined_df.to_csv(output_file, index=False)
    print(f"Combined dataset saved to {output_file}")
    print(f"Total rows: {len(combined_df)}")

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description='Combine multiple Street Fighter 2 datasets')
    parser.add_argument('--dir', default='dataset', help='Directory containing CSV datasets')
    parser.add_argument('--output', default='combined_dataset.csv', help='Output file name')
    
    args = parser.parse_args()
    combine_datasets(args.dir, args.output)
