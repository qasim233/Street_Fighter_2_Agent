import os
import csv
import time
from controller import Controller
from command import Command
from buttons import Buttons

class DataCollector:
    def __init__(self, player_num):
        self.player_num = player_num
        self.dataset = []
        self.header = [
            'timer', 'fight_result', 'has_round_started', 'is_round_over',
            'p1_id', 'p1_health', 'p1_x', 'p1_y', 'p1_jumping', 'p1_crouching', 'p1_in_move', 'p1_move_id',
            'p1_btn_up', 'p1_btn_down', 'p1_btn_right', 'p1_btn_left', 'p1_btn_Y', 'p1_btn_B', 'p1_btn_X', 'p1_btn_A', 'p1_btn_L', 'p1_btn_R',
            'p2_id', 'p2_health', 'p2_x', 'p2_y', 'p2_jumping', 'p2_crouching', 'p2_in_move', 'p2_move_id',
            'p2_btn_up', 'p2_btn_down', 'p2_btn_right', 'p2_btn_left', 'p2_btn_Y', 'p2_btn_B', 'p2_btn_X', 'p2_btn_A', 'p2_btn_L', 'p2_btn_R'
        ]
        
        # Create dataset directory if it doesn't exist
        if not os.path.exists('dataset'):
            os.makedirs('dataset')
    
    def record_game_state(self, game_state, command):
        # Extract data from game state
        row = [
            game_state.timer,
            game_state.fight_result,
            game_state.has_round_started,
            game_state.is_round_over,
            
            # Player 1 data
            game_state.player1.player_id,
            game_state.player1.health,
            game_state.player1.x_coord,
            game_state.player1.y_coord,
            game_state.player1.is_jumping,
            game_state.player1.is_crouching,
            game_state.player1.in_move,
            game_state.player1.move_id,
            
            # Player 1 buttons
            command.p1_buttons.up if self.player_num == '1' else False,
            command.p1_buttons.down if self.player_num == '1' else False,
            command.p1_buttons.right if self.player_num == '1' else False,
            command.p1_buttons.left if self.player_num == '1' else False,
            command.p1_buttons.Y if self.player_num == '1' else False,
            command.p1_buttons.B if self.player_num == '1' else False,
            command.p1_buttons.X if self.player_num == '1' else False,
            command.p1_buttons.A if self.player_num == '1' else False,
            command.p1_buttons.L if self.player_num == '1' else False,
            command.p1_buttons.R if self.player_num == '1' else False,
            
            # Player 2 data
            game_state.player2.player_id,
            game_state.player2.health,
            game_state.player2.x_coord,
            game_state.player2.y_coord,
            game_state.player2.is_jumping,
            game_state.player2.is_crouching,
            game_state.player2.in_move,
            game_state.player2.move_id,
            
            # Player 2 buttons
            command.p2_buttons.up if self.player_num == '2' else False,
            command.p2_buttons.down if self.player_num == '2' else False,
            command.p2_buttons.right if self.player_num == '2' else False,
            command.p2_buttons.left if self.player_num == '2' else False,
            command.p2_buttons.Y if self.player_num == '2' else False,
            command.p2_buttons.B if self.player_num == '2' else False,
            command.p2_buttons.X if self.player_num == '2' else False,
            command.p2_buttons.A if self.player_num == '2' else False,
            command.p2_buttons.L if self.player_num == '2' else False,
            command.p2_buttons.R if self.player_num == '2' else False
        ]
        
        self.dataset.append(row)
    
    def save_dataset(self):
        timestamp = int(time.time())
        filename = f'dataset/sf2_data_{self.player_num}_{timestamp}.csv'
        
        with open(filename, 'w', newline='') as f:
            writer = csv.writer(f)
            writer.writerow(self.header)
            writer.writerows(self.dataset)
        
        print(f"Dataset saved to {filename}")
        return filename

def main():
    import sys
    
    if len(sys.argv) != 2 or sys.argv[1] not in ['1', '2']:
        print("Usage: python data_collector.py [1|2]")
        print("1 for player 1, 2 for player 2")
        sys.exit(1)
    
    player_num = sys.argv[1]
    collector = DataCollector(player_num)
    controller = Controller(player_num)
    
    print("Connecting to game...")
    controller.connect()
    print("Connected successfully!")
    
    try:
        while True:
            # Get current game state
            game_state = controller.get_game_state()
            
            # Create a command based on user input (this will be recorded)
            command = Command()
            
            # Record the game state and command
            collector.record_game_state(game_state, command)
            
            # Send the command to the game
            controller.send_command(command)
            
            # Check if round is over
            if game_state.is_round_over:
                print("Round over! Saving dataset...")
                collector.save_dataset()
                break
    
    except KeyboardInterrupt:
        print("\nData collection interrupted. Saving dataset...")
        collector.save_dataset()
    
    except Exception as e:
        print(f"Error: {e}")
        collector.save_dataset()
    
    finally:
        controller.close()

if __name__ == "__main__":
    main()
