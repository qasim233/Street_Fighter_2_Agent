# Street Fighter 2 AI Agent

This project implements an AI agent for Street Fighter 2 using neural networks. The agent learns to play the game by observing gameplay data and training a model to predict button presses based on the game state.

## Project Structure

- `data_collector.py`: Script to collect gameplay data while you play
- `model_trainer.py`: Script to train a neural network model on the collected data
- `bot.py`: Implementation of the AI agent that uses the trained model
- `combine_datasets.py`: Utility to combine multiple datasets
- `run_bot.py`: Script to run the trained bot

## Setup

1. Download and extract the API from the provided link
2. Place these Python files in the API directory
3. Follow the setup instructions for running the emulator

## Usage

### Step 1: Collect Data

Play the game manually while recording your actions:

\`\`\`bash
python data_collector.py 1  # For player 1
\`\`\`

This will save your gameplay data to the `dataset` directory.

### Step 2: Combine Datasets (Optional)

If you've collected multiple datasets, you can combine them:

\`\`\`bash
python combine_datasets.py --dir dataset --output combined_dataset.csv
\`\`\`

### Step 3: Train the Model

Train a neural network on your gameplay data:

\`\`\`bash
python model_trainer.py dataset/your_dataset.csv
\`\`\`

This will train a model and save it to the `models` directory.

### Step 4: Run the Bot

Run the trained bot:

\`\`\`bash
python run_bot.py 1  # For player 1
\`\`\`

## How It Works

1. **Data Collection**: The `data_collector.py` script records the game state and your button presses while you play.
2. **Data Processing**: The `model_trainer.py` script preprocesses the data and trains a neural network to predict button presses based on the game state.
3. **Bot Implementation**: The `bot.py` file implements the AI agent that uses the trained model to play the game.

## Model Architecture

The neural network model consists of:
- Input layer: Game state features (player positions, health, etc.)
- Hidden layers: Multiple dense layers with dropout and batch normalization
- Output layer: 10 outputs representing button presses (sigmoid activation)

## Notes

- The model performs best when trained on a large and diverse dataset
- Different characters may require different strategies
- The fallback strategy is used when the model isn't loaded or for exploration
