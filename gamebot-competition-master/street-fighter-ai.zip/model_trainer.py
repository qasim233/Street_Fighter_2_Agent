import os
import pandas as pd
import numpy as np
import tensorflow as tf
from tensorflow.keras.models import Sequential, load_model
from tensorflow.keras.layers import Dense, Dropout, BatchNormalization
from tensorflow.keras.callbacks import ModelCheckpoint, EarlyStopping
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler

class StreetFighterModel:
    def __init__(self):
        self.model = None
        self.scaler_X = StandardScaler()
        self.button_columns = [
            'btn_up', 'btn_down', 'btn_right', 'btn_left', 
            'btn_Y', 'btn_B', 'btn_X', 'btn_A', 'btn_L', 'btn_R'
        ]
        
        # Create models directory if it doesn't exist
        if not os.path.exists('models'):
            os.makedirs('models')
    
    def preprocess_data(self, data_path):
        print(f"Loading data from {data_path}")
        df = pd.read_csv(data_path)
        
        # Filter out rows where the round hasn't started or is over
        df = df[df['has_round_started'] & ~df['is_round_over']]
        
        # Determine which player we're controlling based on the data
        player_prefix = 'p1' if any(df[f'p1_{btn}'] for btn in self.button_columns) else 'p2'
        opponent_prefix = 'p2' if player_prefix == 'p1' else 'p1'
        
        print(f"Training model for {player_prefix}")
        
        # Features: game state information
        X_columns = [
            'timer',
            f'{player_prefix}_id', f'{player_prefix}_health', f'{player_prefix}_x', f'{player_prefix}_y',
            f'{player_prefix}_jumping', f'{player_prefix}_crouching', f'{player_prefix}_in_move', f'{player_prefix}_move_id',
            f'{opponent_prefix}_id', f'{opponent_prefix}_health', f'{opponent_prefix}_x', f'{opponent_prefix}_y',
            f'{opponent_prefix}_jumping', f'{opponent_prefix}_crouching', f'{opponent_prefix}_in_move', f'{opponent_prefix}_move_id'
        ]
        
        # Target: button presses
        y_columns = [f'{player_prefix}_{btn}' for btn in self.button_columns]
        
        # Extract features and targets
        X = df[X_columns].copy()
        y = df[y_columns].copy()
        
        # Convert boolean columns to int
        for col in X.columns:
            if X[col].dtype == bool:
                X[col] = X[col].astype(int)
        
        # Normalize features
        X_scaled = self.scaler_X.fit_transform(X)
        
        # Split data
        X_train, X_test, y_train, y_test = train_test_split(X_scaled, y, test_size=0.2, random_state=42)
        
        return X_train, X_test, y_train, y_test, player_prefix
    
    def build_model(self, input_shape, output_shape):
        model = Sequential([
            Dense(128, activation='relu', input_shape=(input_shape,)),
            BatchNormalization(),
            Dropout(0.3),
            
            Dense(256, activation='relu'),
            BatchNormalization(),
            Dropout(0.3),
            
            Dense(128, activation='relu'),
            BatchNormalization(),
            Dropout(0.3),
            
            Dense(64, activation='relu'),
            BatchNormalization(),
            Dropout(0.2),
            
            Dense(output_shape, activation='sigmoid')
        ])
        
        model.compile(
            optimizer='adam',
            loss='binary_crossentropy',
            metrics=['accuracy']
        )
        
        return model
    
    def train(self, data_path, epochs=50, batch_size=32):
        X_train, X_test, y_train, y_test, player_prefix = self.preprocess_data(data_path)
        
        # Build model
        self.model = self.build_model(X_train.shape[1], y_train.shape[1])
        
        # Callbacks
        checkpoint = ModelCheckpoint(
            f'models/sf2_model_{player_prefix}.h5',
            monitor='val_loss',
            save_best_only=True,
            verbose=1
        )
        
        early_stopping = EarlyStopping(
            monitor='val_loss',
            patience=10,
            restore_best_weights=True,
            verbose=1
        )
        
        # Train model
        history = self.model.fit(
            X_train, y_train,
            validation_data=(X_test, y_test),
            epochs=epochs,
            batch_size=batch_size,
            callbacks=[checkpoint, early_stopping],
            verbose=1
        )
        
        # Evaluate model
        loss, accuracy = self.model.evaluate(X_test, y_test)
        print(f"Test Loss: {loss:.4f}")
        print(f"Test Accuracy: {accuracy:.4f}")
        
        # Save scaler
        import joblib
        joblib.dump(self.scaler_X, f'models/scaler_{player_prefix}.pkl')
        
        return history
    
    def save_model(self, path):
        if self.model is not None:
            self.model.save(path)
            print(f"Model saved to {path}")
    
    def load_model(self, model_path, scaler_path):
        self.model = load_model(model_path)
        
        import joblib
        self.scaler_X = joblib.load(scaler_path)
        
        print(f"Model loaded from {model_path}")
        print(f"Scaler loaded from {scaler_path}")

def main():
    import sys
    
    if len(sys.argv) != 2:
        print("Usage: python model_trainer.py <data_path>")
        sys.exit(1)
    
    data_path = sys.argv[1]
    
    if not os.path.exists(data_path):
        print(f"Error: Data file {data_path} not found")
        sys.exit(1)
    
    model = StreetFighterModel()
    history = model.train(data_path)
    
    print("Training complete!")

if __name__ == "__main__":
    main()
