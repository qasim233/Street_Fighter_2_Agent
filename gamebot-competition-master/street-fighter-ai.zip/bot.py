import os
import numpy as np
import tensorflow as tf
from command import Command
from buttons import Buttons
import joblib

class StreetFighterBot:
    def __init__(self, player_num):
        self.player_num = player_num
        self.model = None
        self.scaler = None
        self.button_columns = [
            'btn_up', 'btn_down', 'btn_right', 'btn_left', 
            'btn_Y', 'btn_B', 'btn_X', 'btn_A', 'btn_L', 'btn_R'
        ]
        
        # Load model and scaler
        self.load_model()
    
    def load_model(self):
        player_prefix = f'p{self.player_num}'
        model_path = f'models/sf2_model_{player_prefix}.h5'
        scaler_path = f'models/scaler_{player_prefix}.pkl'
        
        if os.path.exists(model_path) and os.path.exists(scaler_path):
            print(f"Loading model from {model_path}")
            self.model = tf.keras.models.load_model(model_path)
            self.scaler = joblib.load(scaler_path)
            print("Model and scaler loaded successfully")
        else:
            print(f"Warning: Model or scaler not found at {model_path} or {scaler_path}")
            print("Bot will use fallback strategy")
    
    def prepare_input(self, game_state):
        # Determine player and opponent based on player_num
        if self.player_num == '1':
            player = game_state.player1
            opponent = game_state.player2
        else:
            player = game_state.player2
            opponent = game_state.player1
        
        # Create feature vector
        features = [
            game_state.timer,
            player.player_id, player.health, player.x_coord, player.y_coord,
            int(player.is_jumping), int(player.is_crouching), int(player.in_move), player.move_id,
            opponent.player_id, opponent.health, opponent.x_coord, opponent.y_coord,
            int(opponent.is_jumping), int(opponent.is_crouching), int(opponent.in_move), opponent.move_id
        ]
        
        # Convert to numpy array and reshape
        features = np.array(features).reshape(1, -1)
        
        # Scale features if scaler is available
        if self.scaler is not None:
            features = self.scaler.transform(features)
        
        return features
    
    def predict_buttons(self, features):
        if self.model is None:
            # Fallback strategy if model isn't loaded
            return self.fallback_strategy()
        
        # Predict button presses
        predictions = self.model.predict(features)[0]
        
        # Convert predictions to button presses (threshold at 0.5)
        button_presses = (predictions > 0.5).astype(int)
        
        # Create buttons object
        buttons = Buttons()
        
        # Set button states based on predictions
        buttons.up = bool(button_presses[0])
        buttons.down = bool(button_presses[1])
        buttons.right = bool(button_presses[2])
        buttons.left = bool(button_presses[3])
        buttons.Y = bool(button_presses[4])
        buttons.B = bool(button_presses[5])
        buttons.X = bool(button_presses[6])
        buttons.A = bool(button_presses[7])
        buttons.L = bool(button_presses[8])
        buttons.R = bool(button_presses[9])
        
        return buttons
    
    def fallback_strategy(self):
        """Simple fallback strategy if model isn't loaded"""
        buttons = Buttons()
        
        # Random action with low probability
        if np.random.random() < 0.2:
            # Random movement
            move_choice = np.random.choice(['up', 'down', 'left', 'right', 'attack'])
            
            if move_choice == 'up':
                buttons.up = True
            elif move_choice == 'down':
                buttons.down = True
            elif move_choice == 'left':
                buttons.left = True
            elif move_choice == 'right':
                buttons.right = True
            elif move_choice == 'attack':
                attack_button = np.random.choice(['Y', 'B', 'X', 'A'])
                if attack_button == 'Y':
                    buttons.Y = True
                elif attack_button == 'B':
                    buttons.B = True
                elif attack_button == 'X':
                    buttons.X = True
                elif attack_button == 'A':
                    buttons.A = True
        
        return buttons
    
    def fight(self, game_state):
        # Create command object
        command = Command()
        
        # Skip if round hasn't started or is over
        if not game_state.has_round_started or game_state.is_round_over:
            return command
        
        # Prepare input features
        features = self.prepare_input(game_state)
        
        # Predict button presses
        buttons = self.predict_buttons(features)
        
        # Set buttons in command
        if self.player_num == '1':
            command.p1_buttons = buttons
        else:
            command.p2_buttons = buttons
        
        return command

# This function will be called by controller.py
def fight(game_state, player_num):
    global bot
    
    # Initialize bot if not already initialized
    if 'bot' not in globals():
        bot = StreetFighterBot(player_num)
    
    # Get command from bot
    return bot.fight(game_state)
