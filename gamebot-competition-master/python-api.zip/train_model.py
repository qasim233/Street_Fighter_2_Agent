from neural_network import StreetFighterNN
import argparse

def main():
    parser = argparse.ArgumentParser(description='Train Street Fighter II Neural Network')
    parser.add_argument('--data', type=str, default='training_data.csv', help='Path to training data CSV')
    parser.add_argument('--model', type=str, default='sf_model.h5', help='Path to save/load model')
    parser.add_argument('--epochs', type=int, default=50, help='Number of training epochs')
    parser.add_argument('--batch_size', type=int, default=32, help='Batch size for training')
    
    args = parser.parse_args()
    
    print(f"Training model with data from {args.data}")
    nn = StreetFighterNN(model_path=args.model)
    history = nn.train(args.data, epochs=args.epochs, batch_size=args.batch_size)
    
    print("Training complete!")

if __name__ == "__main__":
    main()
