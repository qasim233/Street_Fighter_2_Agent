# Street Fighter II Neural Network Bot

This project implements a neural network-based AI agent for Street Fighter II using the provided API. The agent learns from gameplay data and makes decisions based on the current game state.

## Components

- `bot.py`: The main bot implementation that uses a neural network to decide actions
- `neural_network.py`: Neural network model for predicting button presses
- `data_collector.py`: Utility for collecting training data during gameplay
- `train_model.py`: Script for training the neural network on collected data
- `controller.py`: Modified controller with command-line arguments for different modes

## Usage

### 1. Data Collection

First, collect training data by playing the game with the rule-based bot:

\`\`\`
python controller.py 1 --collect --rule_based
\`\`\`

This will record gameplay data to `training_data.csv`.

### 2. Training the Model

Train the neural network on the collected data:

\`\`\`
python train_model.py --data training_data.csv --epochs 100
\`\`\`

### 3. Running the Neural Network Bot

Run the bot with the trained neural network:

\`\`\`
python controller.py 1
\`\`\`

For player 2:

\`\`\`
python controller.py 2
\`\`\`

## How It Works

1. **Data Collection**: The bot records game states and actions during gameplay
2. **Feature Engineering**: Game state is converted into numerical features
3. **Neural Network**: A multi-layer neural network predicts button presses
4. **Decision Making**: The bot sets buttons based on neural network predictions

## Neural Network Architecture

- Input layer: 17 neurons (game state features)
- Hidden layers: 128 → 256 → 128 neurons with ReLU activation and dropout
- Output layer: 12 neurons with sigmoid activation (one for each button)

## Features Used

- Player health
- Player positions (x, y coordinates)
- Distance between players
- Player states (jumping, crouching, in move)
- Move IDs
- Timer
