import numpy as np
import tensorflow as tf
from tensorflow.keras.models import Sequential, load_model
from tensorflow.keras.layers import Dense, Dropout
from tensorflow.keras.optimizers import Adam
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
import os

class StreetFighterNN:
    def __init__(self, model_path="sf_model.h5"):
        self.model_path = model_path
        self.model = None
        self.scaler = StandardScaler()
        
        # Define input and output dimensions
        self.input_dim = 17  # Number of features
        self.output_dim = 12  # Number of buttons
        
        # Try to load existing model
        if os.path.exists(model_path):
            try:
                self.model = load_model(model_path)
                print(f"Loaded model from {model_path}")
            except:
                print(f"Could not load model from {model_path}, creating new model")
                self._create_model()
        else:
            self._create_model()
    
    def _create_model(self):
        """Create a new neural network model"""
        model = Sequential([
            Dense(128, activation='relu', input_dim=self.input_dim),
            Dropout(0.3),
            Dense(256, activation='relu'),
            Dropout(0.3),
            Dense(128, activation='relu'),
            Dropout(0.3),
            Dense(self.output_dim, activation='sigmoid')  # Sigmoid for multi-label classification
        ])
        
        model.compile(
            optimizer=Adam(learning_rate=0.001),
            loss='binary_crossentropy',
            metrics=['accuracy']
        )
        
        self.model = model
        print("Created new model")
    
    def train(self, data_path, epochs=50, batch_size=32):
        """Train the neural network on collected data"""
        # Load data
        data = pd.read_csv(data_path)
        
        # Split features and labels
        X = data.iloc[:, :self.input_dim].values  # First 17 columns are features
        y = data.iloc[:, self.input_dim:].values  # Last 12 columns are button states
        
        # Split data into training and validation sets
        X_train, X_val, y_train, y_val = train_test_split(X, y, test_size=0.2, random_state=42)
        
        # Normalize features
        self.scaler.fit(X_train)
        X_train = self.scaler.transform(X_train)
        X_val = self.scaler.transform(X_val)
        
        # Train the model
        history = self.model.fit(
            X_train, y_train,
            epochs=epochs,
            batch_size=batch_size,
            validation_data=(X_val, y_val),
            verbose=1
        )
        
        # Save the model
        self.model.save(self.model_path)
        print(f"Model saved to {self.model_path}")
        
        return history
    
    def predict(self, game_state, player):
        """Predict button presses based on game state"""
        # Extract features from game state
        if player == "1":
            my_player = game_state.player1
            opponent = game_state.player2
        else:
            my_player = game_state.player2
            opponent = game_state.player1
        
        # Calculate distance between players
        x_distance = opponent.x_coord - my_player.x_coord
        y_distance = opponent.y_coord - my_player.y_coord
        
        # Create feature vector
        features = np.array([
            my_player.health, opponent.health,
            my_player.x_coord, my_player.y_coord, 
            opponent.x_coord, opponent.y_coord,
            x_distance, y_distance,
            int(my_player.is_jumping), int(my_player.is_crouching),
            int(opponent.is_jumping), int(opponent.is_crouching),
            int(my_player.is_player_in_move), int(opponent.is_player_in_move),
            my_player.move_id, opponent.move_id,
            game_state.timer
        ]).reshape(1, -1)
        
        # Normalize features
        features = self.scaler.transform(features)
        
        # Predict button presses
        predictions = self.model.predict(features)[0]
        
        # Convert predictions to binary (0 or 1) based on threshold
        threshold = 0.5
        binary_predictions = (predictions > threshold).astype(int)
        
        return binary_predictions
