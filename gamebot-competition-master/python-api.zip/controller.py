import socket
import json
from game_state import GameState
import sys
from bot import Bot
import argparse

def connect(port):
    # For making a connection with the game
    server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    server_socket.bind(("127.0.0.1", port))
    server_socket.listen(5)
    (client_socket, _) = server_socket.accept()
    print("Connected to game!")
    return client_socket

def send(client_socket, command):
    # This function will send your updated command to Bizhawk so that game reacts according to your command.
    command_dict = command.object_to_dict()
    pay_load = json.dumps(command_dict).encode()
    client_socket.sendall(pay_load)

def receive(client_socket):
    # receive the game state and return game state
    pay_load = client_socket.recv(4096)
    input_dict = json.loads(pay_load.decode())
    game_state = GameState(input_dict)
    return game_state

def main():
    parser = argparse.ArgumentParser(description='Street Fighter II Neural Network Bot')
    parser.add_argument('player', type=str, choices=['1', '2'], help='Player number (1 or 2)')
    parser.add_argument('--collect', action='store_true', help='Enable data collection mode')
    parser.add_argument('--rule_based', action='store_true', help='Use rule-based bot instead of neural network')
    
    args = parser.parse_args()
    
    if args.player == '1':
        client_socket = connect(9999)
    else:
        client_socket = connect(10000)
    
    current_game_state = None
    bot = Bot(collect_data=args.collect)
    
    print(f"Bot initialized for player {args.player}")
    if args.collect:
        print("Data collection mode enabled")
    if args.rule_based:
        print("Using rule-based bot")
    
    while (current_game_state is None) or (not current_game_state.is_round_over):
        current_game_state = receive(client_socket)
        
        if args.rule_based:
            bot_command = bot.rule_based_fight(current_game_state, args.player)
        else:
            bot_command = bot.fight(current_game_state, args.player)
            
        send(client_socket, bot_command)

if __name__ == '__main__':
    main()
