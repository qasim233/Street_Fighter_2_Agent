import csv
import os
import numpy as np
from game_state import GameState
from command import Command
from buttons import Buttons

class DataCollector:
    def __init__(self, file_path="training_data.csv"):
        self.file_path = file_path
        self.header_written = os.path.exists(file_path) and os.path.getsize(file_path) > 0
        
        # Create file if it doesn't exist
        if not self.header_written:
            with open(self.file_path, 'w', newline='') as f:
                writer = csv.writer(f)
                # Define header with features and actions
                header = [
                    # Game state features
                    'p1_health', 'p2_health', 
                    'p1_x', 'p1_y', 'p2_x', 'p2_y',
                    'x_distance', 'y_distance',
                    'p1_jumping', 'p1_crouching', 
                    'p2_jumping', 'p2_crouching',
                    'p1_in_move', 'p2_in_move',
                    'p1_move_id', 'p2_move_id',
                    'timer',
                    # Button actions (output)
                    'up', 'down', 'left', 'right',
                    'Y', 'B', 'X', 'A', 'L', 'R',
                    'select', 'start'
                ]
                writer.writerow(header)
    
    def record(self, game_state, command, player):
        """Record the current game state and the command issued"""
        with open(self.file_path, 'a', newline='') as f:
            writer = csv.writer(f)
            
            # Extract player data based on which player we're controlling
            if player == "1":
                my_player = game_state.player1
                opponent = game_state.player2
                buttons = command.player_buttons
            else:
                my_player = game_state.player2
                opponent = game_state.player1
                buttons = command.player2_buttons
            
            # Calculate distance between players
            x_distance = opponent.x_coord - my_player.x_coord
            y_distance = opponent.y_coord - my_player.y_coord
            
            # Create row with features and actions
            row = [
                # Game state features
                my_player.health, opponent.health,
                my_player.x_coord, my_player.y_coord, 
                opponent.x_coord, opponent.y_coord,
                x_distance, y_distance,
                int(my_player.is_jumping), int(my_player.is_crouching),
                int(opponent.is_jumping), int(opponent.is_crouching),
                int(my_player.is_player_in_move), int(opponent.is_player_in_move),
                my_player.move_id, opponent.move_id,
                game_state.timer,
                # Button actions (output)
                int(buttons.up), int(buttons.down), 
                int(buttons.left), int(buttons.right),
                int(buttons.Y), int(buttons.B), 
                int(buttons.X), int(buttons.A),
                int(buttons.L), int(buttons.R),
                int(buttons.select), int(buttons.start)
            ]
            writer.writerow(row)
